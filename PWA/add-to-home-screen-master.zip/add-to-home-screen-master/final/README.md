# Fireworks!

[![Fireworks](http://lab.aerotwist.com/canvas/fireworks/capture.png)](http://lab.aerotwist.com/canvas/fireworks/)

Everyone loves them, and now you can make them with HTML5's canvas tag. This is the code from the tutorial I put
together for [CreativeJS](http://creativejs.com/), and you can see the final effect [here](http://lab.aerotwist.com/canvas/fireworks/).

