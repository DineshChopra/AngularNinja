# Card Game Backend application

* Start server "npm start"

## Rest api expose list
* http://localhost:3010/api/bank
* http://localhost:3010/api/card