var express = require('express');
var router = express.Router();

var banks = [
    {name : 'State Bank of India', id : 1},
    {name : 'Axis Bank', id : 2},
    {name : 'ICICI Bank', id : 3}
]
router.get('/', function (req, res, next) {
    res.status(200).json({
        message : 'Success',
        data : banks
    });
});

module.exports = router;
